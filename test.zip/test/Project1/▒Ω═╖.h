#pragma once
class experiment {
public:
	int input(int A, int B, int X);
};