#include<iostream>
#include<cstdlib>
#include"��ͷ.h"
using namespace std;

int experiment::input(int A, int B, int X) {
	if ((A > 1) && (B == 0)) {
		X = X / A;
	}
	if ((A == 2) || (X > 1))
	{
		X = X + 1;
	}
	return X;
}

int main()
{
	experiment exp1;
	cout << "·��1457(1,1,1):X=" << exp1.input(1, 1, 1) << endl;
	cout << "·��14567(1,1,2):X=" << exp1.input(1, 1, 2) << endl;
	cout << "·��12457(3,1,3):X=" << exp1.input(3, 1, 3) << endl;
	cout << "·��123467(1,1,1):X=" << exp1.input(2, 0, 4) << endl;
	return 0;
}