﻿#include "pch.h"
#include "CppUnitTest.h"
#include "F:\Visual Studio2017\vs项目\Project1\Project1\源.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		experiment test;
		
		TEST_METHOD(TestMethod1)
		{
			Assert::AreEqual(1, test.input(1, 1, 1));
		}
		TEST_METHOD(TestMethod2)
		{
			Assert::AreEqual(3, test.input(1, 1, 2));
		}
		TEST_METHOD(TestMethod3)
		{
			Assert::AreEqual(4, test.input(3, 1, 3));
		}
		TEST_METHOD(TestMethod4)
		{
			Assert::AreEqual(3, test.input(2, 0, 4));
		}
	};
}
